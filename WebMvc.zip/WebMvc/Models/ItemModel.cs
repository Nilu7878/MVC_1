using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebMvc.Models
{
    public class ItemModel
    {
         public int c_itemid { get; set; }

    [Required(ErrorMessage = "Item name is required.")]
    [StringLength(255, ErrorMessage = "Item name must be between 1 and 255 characters.", MinimumLength = 1)]
    public string c_itemname { get; set; }

    [Required(ErrorMessage = "Category ID is required.")]
    public int c_categoryid { get; set; }

    [StringLength(255, ErrorMessage = "Item image must be between 0 and 255 characters.", MinimumLength = 0)]
    public string? c_itemimage { get; set; }

    [Required(ErrorMessage = "Item cost is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Item cost must be a positive number.")]
    public int c_itemcost { get; set; }

    [Required(ErrorMessage = "Initial stock is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Initial stock must be a positive number.")]
    public int c_initialstock { get; set; }

    [Required(ErrorMessage = "Available stock is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Available stock must be a positive number.")]
    public int c_availablestock { get; set; }
     public string? c_categoryname { get; set; }

      public int c_qty { get; set; }
        // public int c_totalcost { get; set; }
        public decimal c_totalcost { get; set; }


        public int c_id { get; set; }
        public int c_purchaseid { get; set; }

        public string? c_name {get;set;}

    }
}