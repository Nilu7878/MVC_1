using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Npgsql;
using WebMvc.Models;

namespace WebMvc.Repositories
{
    public class UserRepositories : CommanRepositories, IUserRepositories
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserRepositories(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public bool RegistrationRecord(RegisterModel reg)
        {
            try
            {
                conn.Open();
                var checkQuery = "SELECT COUNT(*) FROM public.t_auth118 WHERE c_email = @c_email";
                using var checkCommand = new NpgsqlCommand(checkQuery, conn);
                checkCommand.Parameters.AddWithValue("@c_email", reg.c_email);
                if (Convert.ToInt32(checkCommand.ExecuteScalar()) > 0) return false;

                using NpgsqlCommand cmd = new NpgsqlCommand("insert into public.t_auth118 values(DEFAULT,@name,@email,@password,false)", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", reg.c_name);
                cmd.Parameters.AddWithValue("@email", reg.c_email);
                cmd.Parameters.AddWithValue("@password", reg.c_password);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while inserting" + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public RegisterModel Login(RegisterModel model)
        {
            try
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand("SELECT c_status,c_id,c_name,c_email,c_password FROM public.t_auth118 WHERE c_email = @Email AND c_password = @Password", conn))
                {

                    cmd.Parameters.AddWithValue("@Email", model.c_email);
                    cmd.Parameters.AddWithValue("@Password", model.c_password);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            var httpContext = _httpContextAccessor.HttpContext.Session;
                            _httpContextAccessor.HttpContext.Session.SetString("c_id", reader["c_id"].ToString());
                            // httpContext.SetString("UserName", model.c_name);
                            httpContext.SetString("UserName", reader.GetString(reader.GetOrdinal("c_name")));
                            httpContext.SetString("UserEmail", model.c_email);
                            RegisterModel user = new RegisterModel
                            {
                                c_status = reader.GetBoolean(0),
                                c_email = reader["c_email"].ToString(),
                                c_password = reader["c_password"].ToString()
                            };
                            return user;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while logging in: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return null;
        }
    }
}