using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebMvc.Models;

namespace WebMvc.Repositories
{
    public interface IUserRepositories
    {
        bool RegistrationRecord(RegisterModel reg);

        RegisterModel Login(RegisterModel reg);
    }
}