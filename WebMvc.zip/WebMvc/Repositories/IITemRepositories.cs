using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebMvc.Models;

namespace WebMvc.Repositories
{
    public interface IITemRepositories
    {
        void Categoryfill(CategoryModel t);
        List<CategoryModel> FetchAllItemRecord();

        void insertAdmin(ItemModel t);
        List<ItemModel> FetchAllItems();
        void UpdateItem(ItemModel item);
        ItemModel FetchByID(int id);

        void DeleteRecord(int id);

        List<ItemModel> FetchUserItems();
        ItemModel ShowItem(int id);
        List<ItemModel> FetchPurchaseData();

        void paymentinsert(ItemModel p);
        void DeletePurchaseRecord(int id);
    }
}