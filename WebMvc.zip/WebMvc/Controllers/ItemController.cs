using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using WebMvc.Models;
using WebMvc.Repositories;

namespace WebMvc.Controllers
{
    // [Route("[controller]")]
    public class ItemController : Controller
    {
        private readonly IITemRepositories _iitemRepositories;

        private readonly IWebHostEnvironment _environment;
        private readonly ILogger<ItemController> _logger;

        public ItemController(ILogger<ItemController> logger, IITemRepositories iitemRepositories, IWebHostEnvironment environment)
        {
            _logger = logger;
            _iitemRepositories = iitemRepositories;
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult PaymentPage(int id)
        {
            var it = _iitemRepositories.ShowItem(id);
            return View(it);
        }
        public IActionResult Category()
        {
            return View();
        }
        public IActionResult PurchaseItem()
        {
        
            var item = _iitemRepositories.FetchAllItems();
            return View(item);
        }

        public IActionResult ViewPurchaseItem()
        {
            var item = _iitemRepositories.FetchUserItems();
            return View(item);
        }
        [HttpGet]
        public IActionResult thankyou()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Paymentpage(ItemModel ite)
        {
            _iitemRepositories.paymentinsert(ite);
            // Redirect to the ItemDisplay action
            return RedirectToAction("thankyou", "Dashboard");
        }

        [HttpGet]
        public IActionResult itemDisplay()
        {
            var item = _iitemRepositories.FetchAllItems();
            return View(item);
        }
        [HttpGet]
        public IActionResult ShowPurchaseData()
        {
            var item1 = _iitemRepositories.FetchPurchaseData();
            return View(item1);
        }

        [HttpGet]
        public IActionResult updateitem(int id)
        {
            List<CategoryModel> tasks = _iitemRepositories.FetchAllItemRecord();
            ViewBag.Tasks = new SelectList(tasks, "c_categoryid", "c_categoryname");
            var rec = _iitemRepositories.FetchByID(id);
            return View(rec);
        }
        [HttpPost]
        public IActionResult ViewPurchaseItem(int id)
        {
            _iitemRepositories.DeleteRecord(id);
            return RedirectToAction("ViewPurchaseItem");
        }
        [HttpGet]
        public IActionResult DeleteItem(int id)
        {
            _iitemRepositories.DeleteRecord(id);
            return RedirectToAction("itemDisplay");
        }
        [HttpGet]
        public IActionResult DeletePurchaseRecord(int id)
        {
            _iitemRepositories.DeletePurchaseRecord(id);
            return RedirectToAction("ViewPurchaseItem");
        }
        [HttpPost]
        public IActionResult UpdateData(ItemModel item, IFormFile? c_itemimages)
        {
             if (c_itemimages != null)
            {
                string filename = Guid.NewGuid().ToString() + Path.GetExtension(c_itemimages.FileName);
                var filePath = Path.Combine(_environment.WebRootPath, "upload/Photos", filename);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    c_itemimages.CopyTo(stream);
                }
                item.c_itemimage = filename;
            }
            else
            {
                var exist = _iitemRepositories.FetchByID(item.c_itemid);
                item.c_itemimage = exist.c_itemimage;
            }
           _iitemRepositories.UpdateItem(item);
             return RedirectToAction("itemDisplay");
     }
        [HttpPost]
        public IActionResult iteminsert(ItemModel item, IFormFile c_itemimages)
        {
            string filename = Guid.NewGuid().ToString() + Path.GetExtension(c_itemimages.FileName);
            var filePath = Path.Combine(_environment.WebRootPath, "upload/photos", filename);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                c_itemimages.CopyTo(stream);
            }
            item.c_itemimage = filename;
            _iitemRepositories.insertAdmin(item);
            return RedirectToAction("ItemDisplay");
        }


        [HttpGet]
        public IActionResult iteminsert()
        {

            List<CategoryModel> tasks = _iitemRepositories.FetchAllItemRecord();
            ViewBag.Tasks = tasks.Select(t => new SelectListItem { Value = t.c_categoryid.ToString(), Text = t.c_categoryname }).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Category(CategoryModel en)
        {
            if (!ModelState.IsValid)
            {
                return View(en);
            }

            _iitemRepositories.Categoryfill(en);

            return RedirectToAction("iteminsert", "Item");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}