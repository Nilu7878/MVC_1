using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebMvc.Controllers
{
    // [Route("[controller]")]
    public class DashboardController : Controller
    {
        private readonly ILogger<DashboardController> _logger;

        //  private readonly ITaskRepositories _itaskRepositories;

        public DashboardController(ILogger<DashboardController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

         public IActionResult thankyou()
        {
            string UserName = HttpContext.Session.GetString("UserName");
            ViewBag.UserName = UserName;
            return View();
        }
        
         public IActionResult UserDashboard()
        {
             string UserName = HttpContext.Session.GetString("UserName");
            ViewBag.UserName = UserName;
            // User dashboard logic
            return View();
        }

        public IActionResult AdminDashboard()
        {
            string UserName = HttpContext.Session.GetString("UserName");
            ViewData["UserName"] = UserName;
            // Admin dashboard logic
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}