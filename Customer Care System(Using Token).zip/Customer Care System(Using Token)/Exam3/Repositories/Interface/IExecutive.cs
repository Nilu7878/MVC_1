using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Model;

namespace Repositories.Interface
{
    public interface IExecutive
    {
        ExecutiveModel Login(ExecutiveModel login);

        CustomerModel GetOne(int id);

        void ResolveToken(CustomerModel token);
        
    }
}