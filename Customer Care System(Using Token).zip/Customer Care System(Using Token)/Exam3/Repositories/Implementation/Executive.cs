using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Model;

namespace Repositories.Implementation
{
    public class Executive : IExecutive
    {

        private readonly string _conn;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public Executive(IConfiguration configuration,IHttpContextAccessor httpContextAccessor)
        {
            _conn = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }
        public ExecutiveModel Login(ExecutiveModel login)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    using var cmd = new NpgsqlCommand("select * from t_executive where c_loginid=@c_loginid AND c_password=@c_password", conn);
                    cmd.Parameters.AddWithValue("@c_loginid", login.c_loginid);
                    cmd.Parameters.AddWithValue("@c_password", login.c_password);
                    using var dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        var stud = new ExecutiveModel
                        {
                            c_loginid = Convert.ToInt32(dr["c_loginid"]),
                            c_password = dr["c_password"].ToString(),
                            c_type = dr["c_type"].ToString(),
                        };
                        return stud;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception while Login:=" + e.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            return null;
        }

          public void ResolveToken(CustomerModel token)
        {
             using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
            try
            {
                conn.Open();
                var cmd = new NpgsqlCommand("UPDATE t_customer SET c_status='1', c_name=@c_name, c_mobile=@c_mobile WHERE c_tokenid=@c_tokenid", conn);
                cmd.Parameters.AddWithValue("@c_tokenid",token.c_tokenid);
                cmd.Parameters.AddWithValue("@c_name", token.c_name);
                cmd.Parameters.AddWithValue("@c_mobile", token.c_mobile);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }
            }
        }
        public CustomerModel GetOne(int id)
        {
            var token = new CustomerModel();
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand("SELECT c_tokenid, c_type, c_status, c_name, c_mobile FROM t_customer WHERE c_tokenid=@c_tokenid", conn);
                    cmd.Parameters.AddWithValue("@c_tokenid", id);
                    var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {

                        token.c_tokenid = Convert.ToInt32(reader["c_tokenid"]);
                        token.c_type = reader["c_type"].ToString();
                        token.c_status = Convert.ToInt32(reader["c_status"]);
                        // token.c_name = reader["c_name"].ToString();
                        // token.c_mobile = Convert.ToDouble(reader["c_mobile"]);

                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
                finally
                {
                    conn.Close();
                }
                return token;
            }
        }
    }
}