using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using NpgsqlTypes;
using Repositories.Interface;
using Repositories.Model;

namespace Repositories.Implementation
{
    public class Customer : ICustomer
    {
        private readonly string _conn;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public Customer(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _conn = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }
        public int AddToken(CustomerModel t)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                int tokenid = -1;
                try
                {
                    conn.Open();
                    using var cmd = new NpgsqlCommand("INSERT INTO t_customer (c_type) values(@c_type) RETURNING c_tokenid", conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@c_type", t.c_type);
                    var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        tokenid = Convert.ToInt32(reader["c_tokenid"]);

                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Erro While token:=" + e.Message);

                }
                finally
                {
                    conn.Close();
                }
                return tokenid;
            }

        }

        public List<CustomerModel> GetAll()
        {
            var tokens = new List<CustomerModel>();
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    var tokentype = _httpContextAccessor.HttpContext.Session.GetString("TokenType");
                    var cmd = new NpgsqlCommand("SELECT c_type, c_name, c_mobile,c_status,c_tokenid FROM t_customer where c_status!=1 AND c_type=@c_type", conn);
                //  cmd.Parameters.AddWithValue("@c_type",NpgsqlDbType.Text, tokentype);
                    if (string.IsNullOrEmpty(tokentype))
                    {
                        cmd.Parameters.AddWithValue("@c_type", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@c_type", NpgsqlDbType.Text, tokentype);
                    }
                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var token = new CustomerModel
                        {
                            c_type = reader["c_type"].ToString(),
                            c_status = Convert.ToInt32(reader["c_status"]),
                            c_tokenid = Convert.ToInt32(reader["c_tokenid"]),

                        };
                        tokens.Add(token);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error While Fetching" + e.Message);
                }
                finally
                {
                    conn.Close();
                }
                return tokens;
            }
        }
    }
}