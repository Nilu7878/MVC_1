using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Model;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class CustomerController : Controller
    {
        private readonly ILogger<CustomerController> _logger;

        private readonly ICustomer _icustomer;
        public CustomerController(ILogger<CustomerController> logger, ICustomer icustomer)
        {
            _logger = logger;
            _icustomer = icustomer;
        }

        public IActionResult Index()
        {
            return View();
        }
         public IActionResult display()
        {
            var data =_icustomer.GetAll();
            return View(data);
        }
        public IActionResult AddToken()
        {
            return View();
        }
           [HttpPost]
        public IActionResult AddToken(CustomerModel token)
        {
            int tokenid1 = _icustomer.AddToken(token);
            if (tokenid1 > 0)
            {
                TempData["tokenmessage"] = "your token number is " + tokenid1.ToString();
                return RedirectToAction("AddToken", "Customer");
            }

            else
            {
                TempData["tokenerror"] = "error while generating token";
                return View();
            }

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}