using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Model;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class ExecutiveController : Controller
    {
        private readonly ILogger<ExecutiveController> _logger;

        private readonly IExecutive _iexecutive;
    
        public ExecutiveController(ILogger<ExecutiveController> logger,IExecutive iexecutive)
        {
            _logger = logger;
            _iexecutive = iexecutive;
        }

        public IActionResult Index()
        {
            return View();
        }
        
           public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(ExecutiveModel login)
        {
            var user = _iexecutive.Login(login);
            if (user != null)
            {
                HttpContext.Session.SetInt32("userId", user.c_loginid);
                HttpContext.Session.SetString("TokenType", user.c_type);
                return RedirectToAction("display","Customer");
            }
            else
            {
                ViewBag.Error = "Username and password incorrect";
                return View();
            }
        }
        [HttpGet]
        public IActionResult Resolvetoken(int id)
        {
            var tokens = _iexecutive.GetOne(id);
            return View(tokens);
        }
         [HttpPost]
        public IActionResult Resolvetoken(CustomerModel token)
        {
             _iexecutive.ResolveToken(token);
            return RedirectToAction("display","Customer");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}