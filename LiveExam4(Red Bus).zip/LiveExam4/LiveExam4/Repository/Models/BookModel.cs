using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repository.Models
{
    public class BookModel
    {
          public int c_bid {get; set;}
          public int c_uid {get; set;}

        public string? c_trip{get;set;}
        public DateTime c_tdate{get;set;}
        public double  c_price{get;set;}
        public int c_cstock{get;set;}
        public int c_qty{get;set;}
        public double c_cost{get;set;}
        public int c_status{get;set;}
        public double c_tcost{get;set;}
    }
}