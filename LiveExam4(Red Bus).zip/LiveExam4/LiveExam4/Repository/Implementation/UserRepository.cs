using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repository.Models;
using Repository.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Npgsql;
using Repository.Interface;
using System.Data;

namespace Repository.Implementation
{
    public class UserRepository : IUserRepository
    {

        private readonly string _con;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }

// This is login for both  admin and user 
        public AuthModel Login(AuthModel userModel)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand("Select * from t_usermaster Where c_email=@email And c_password=@pass", conn);
                    cmd.Parameters.AddWithValue("@email", userModel.c_email);
                    cmd.Parameters.AddWithValue("@pass", userModel.c_password);
                    var dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        var login = new AuthModel
                        {
                            c_uid = Convert.ToInt32(dr["c_uid"]),
                            c_email = dr["c_email"].ToString(),
                            c_password = dr["c_password"].ToString(),
                            c_status = Convert.ToInt32(dr["c_status"]),
                        };
                        var httpContext = _httpContextAccessor.HttpContext;
                        httpContext.Session.SetInt32("UserId", Convert.ToInt32(dr["c_uid"]));
                        httpContext.Session.SetString("UserEmail", dr["c_email"].ToString());
                        return login;

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                }
                finally
                {
                    conn.Close();
                }
                return null;
            }
        }

//  This is method for add trip by admin
        public bool AddTrip(TripModel tripModel)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand("INSERT INTO t_tripmaster (c_trip, c_price, c_tstock, c_cstock) VALUES (@c_trip, @c_price, @c_tstock, @c_cstock)", conn);
                    cmd.Parameters.AddWithValue("@c_trip", tripModel.c_trip);
                    cmd.Parameters.AddWithValue("@c_price", tripModel.c_price);
                    cmd.Parameters.AddWithValue("@c_tstock", tripModel.c_tstock);
                    cmd.Parameters.AddWithValue("@c_cstock", tripModel.c_cstock);

                    cmd.ExecuteNonQuery();

                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

//  This is fetch all bus details
        public List<TripModel> FetchAll()
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                var records = new List<TripModel>();

                try
                {
                    conn.Open();
                    using var command = new NpgsqlCommand("select * from t_tripmaster", conn);
                    command.CommandType = CommandType.Text;
                    using var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        var trip = new TripModel
                        {
                            c_tid = Convert.ToInt32(reader["c_tid"]),
                            c_trip = reader["c_trip"].ToString(),
                            c_price = Convert.ToInt32(reader["c_price"]),
                            c_tstock = Convert.ToInt32(reader["c_tstock"]),
                            c_cstock = Convert.ToInt32(reader["c_cstock"]),
                        };
                        records.Add(trip);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return records;
            }
        }

// this is for where getting one details from  bus details
        public TripModel Show(int id)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();

                    using var command = new NpgsqlCommand("select * from t_tripmaster where c_tid = @id", conn);
                    command.CommandType = CommandType.Text;
                    command.Parameters.AddWithValue("@id", id);

                    using var reader = command.ExecuteReader();

                    var record = new TripModel();

                    if (reader.Read())
                    {
                        record.c_trip = reader["c_trip"].ToString();
                        record.c_price = Convert.ToInt32(reader["c_price"]);
                        record.c_tstock = Convert.ToInt32(reader["c_tstock"]);
                        record.c_cstock = Convert.ToInt32(reader["c_cstock"]);
                    }
                    return record;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

//  Admin can update the bus  detail by providing trip number 
        public bool Update(TripModel tripModel, int id)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();

                    using var command = new NpgsqlCommand("UPDATE t_tripmaster SET c_trip = @c_trip, c_price = @c_price, c_tstock = @c_tstock , c_cstock=@c_cstock WHERE c_tid = @c_tid", conn);
                    command.CommandType = CommandType.Text;

                    command.Parameters.AddWithValue("@c_tid", id);
                    command.Parameters.AddWithValue("@c_trip", tripModel.c_trip);
                    command.Parameters.AddWithValue("@c_price", tripModel.c_price);
                    command.Parameters.AddWithValue("@c_tstock", tripModel.c_tstock);
                    command.Parameters.AddWithValue("@c_cstock", tripModel.c_cstock);

                    command.ExecuteNonQuery();

                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error updating record: " + ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

//  Delete the bus details  with provided TID by Admin
        public void Delete(int id)
        {

            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();

                    using var command = new NpgsqlCommand("delete from t_tripmaster where c_tid = @c_id", conn);
                    command.Parameters.AddWithValue("@c_id", id);
                    command.CommandType = CommandType.Text;

                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error updating record: " + ex.Message);

                }
                finally
                {
                    conn.Close();
                }
            }

        }

// Admin can seen the history  of all Bus Details (in this departted , scheduled , Cancled)
        public List<BookModel> History()
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                var bookedTrips = new List<BookModel>();

                try
                {
                    conn.Open();
                    using var command = new NpgsqlCommand("SELECT * FROM t_tripbooking", conn);
                    command.CommandType = CommandType.Text;

                    using var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        var bookedTrip = new BookModel
                        {
                            c_bid = Convert.ToInt32(reader["c_bid"]),
                            c_uid = Convert.ToInt32(reader["c_uid"]),
                            c_tdate = Convert.ToDateTime(reader["c_tdate"]),
                            c_price = Convert.ToDouble(reader["c_price"]),
                            c_qty = Convert.ToInt32(reader["c_qty"]),
                            c_tcost = Convert.ToDouble(reader["c_cost"]),
                            c_trip = reader["c_trip"].ToString()
                        };
                        if (Convert.ToInt32(reader["c_status"]) == 1)
                        {
                            bookedTrip.c_status = 1; // Set status to 1 if cancelled
                        }
                        else
                        {
                            var today = DateTime.Today;
                            if (bookedTrip.c_tdate < today)
                            {
                                bookedTrip.c_status = 2; // Set status to 2 if departed
                            }
                            else if (bookedTrip.c_tdate.Date == today)
                            {
                                bookedTrip.c_status = 0; // Set status to 0 if scheduled
                            }
                            else
                            {
                                bookedTrip.c_status = 0; // Set status to 0 if scheduled
                            }
                        }

                        bookedTrips.Add(bookedTrip);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return bookedTrips;
            }
        }

    }
}