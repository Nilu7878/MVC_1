using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repository.Models;

namespace Repository.Interface
{
    public interface IUserRepository
    {
         AuthModel Login(AuthModel authModel);
         bool AddTrip(TripModel tripModel);
         List<TripModel> FetchAll();
         TripModel Show(int id);
        bool Update(TripModel tripModel, int id);
        void Delete(int id);
        List<BookModel> History();
    }
}