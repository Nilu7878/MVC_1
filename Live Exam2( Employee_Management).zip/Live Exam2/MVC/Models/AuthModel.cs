using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVC.Models
{
    public class AuthModel
    {
        public int c_lid { get; set; }
        // [Required(ErrorMessage = "Email is required.")]
        // [StringLength(255, ErrorMessage = "Email cannot exceed 255 characters.")]
        // [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string? c_login { get; set; }
        public string? c_password { get; set; }
        public int c_status { get; set; }
        public string? c_lname { get; set; }
    }
}