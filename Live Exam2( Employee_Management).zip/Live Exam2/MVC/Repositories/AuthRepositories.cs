using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC.Models;
using Npgsql;

namespace MVC.Repositories
{
    public class AuthRepositories : CommonRepositories, IAuthRepositories
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthRepositories(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public void Register(AuthModel register)
        {
            conn.Open();

            using var command = new NpgsqlCommand("Insert into t_login008(c_login, c_password, c_lname) Values(@c_login, @c_password, @c_lname)", conn);
            command.CommandType = CommandType.Text;

            command.Parameters.AddWithValue("@c_login", register.c_login);
            command.Parameters.AddWithValue("@c_password", register.c_password);
            command.Parameters.AddWithValue("@c_lname", register.c_lname);

            command.ExecuteNonQuery();

            conn.Close();
        }

        public AuthModel Login(AuthModel login)
        {
            try
            {
                conn.Open();

                using var command = new NpgsqlCommand("SELECT * FROM t_login008 WHERE c_login = @c_login AND c_password = @c_password", conn);
                command.CommandType = CommandType.Text;

                command.Parameters.AddWithValue("@c_login", login.c_login);
                command.Parameters.AddWithValue("@c_password", login.c_password);

                var dr = command.ExecuteReader();

                if (dr.Read())
                {
                    var session = _httpContextAccessor.HttpContext.Session;
                    _httpContextAccessor.HttpContext.Session.SetString("c_lid", dr["c_lid"].ToString());
                    session.SetString("Name", dr.GetString(dr.GetOrdinal("c_lname")));

                    AuthModel loggedInUser = new AuthModel
                    {
                        c_lid = Convert.ToInt32(dr["c_lid"]),
                        c_login = dr["c_login"].ToString(),
                        c_password = dr["c_password"].ToString(),
                        c_status = Convert.ToInt32(dr["c_status"]),
                        c_lname = dr["c_lname"].ToString()
                    };

                    return loggedInUser;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {

                conn.Close();
            }

            return null;
        }

        public bool IsEmailExists(string c_login)
        {
            try
            {
                conn.Open();
                var query = "SELECT c_lid, c_login, c_password, c_status, c_lname FROM t_login008 WHERE c_login = @c_login";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_login", c_login);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (System.Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}