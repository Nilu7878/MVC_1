using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC.Models;

namespace MVC.Repositories
{
    public interface IEmpRepositories
    {
        List<EmpModel> GetAllDesignation();
        void InsertEmp(EmpModel emp);
        List<EmpModel> FetchAllEmpsForAdmin(EmpModel employee);
        EmpModel ShowEmp(int id);
        void DeleteEmp(int id);
        bool UpdateEmp(int id, EmpModel updatedRecord);
        bool UpdatePayroll(int id, EmpModel updatedRecord);
    }
}