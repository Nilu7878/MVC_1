using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using MVC.Models;
using MVC.Repositories;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class EmpController : Controller
    {
        private readonly ILogger<EmpController> _logger;
        private readonly IEmpRepositories _empRepositories;

        public EmpController(ILogger<EmpController> logger, IEmpRepositories empRepositories)
        {
            _logger = logger;
            _empRepositories = empRepositories;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AdminDashboard()
        {
            string name = HttpContext.Session.GetString("Name");
            ViewBag.Name = name;
            return View();
        }


        [HttpGet]
        public IActionResult AddNewEmployee()
        {
            List<EmpModel> designations = _empRepositories.GetAllDesignation();
            ViewData["Designations"] = new SelectList(designations, "c_did", "c_dname");

            return View();
        }

        [HttpPost]
        public IActionResult AdminDashboard(EmpModel emp)
        {
            _empRepositories.InsertEmp(emp);
            return View("AdminDashboard");
        }

        [HttpGet]
        public IActionResult EmployeeDashboard(EmpModel employee)
        {
            var emp = _empRepositories.FetchAllEmpsForAdmin(employee);
            return View(emp);
        }

        [HttpGet]
        public IActionResult ShowPayroll(int id)
        {
            var emp = _empRepositories.ShowEmp(id);
            return View(emp);
        }

        [HttpPost]
        public IActionResult ShowPayroll(int id, EmpModel updatedItem){
            _empRepositories.UpdatePayroll(id, updatedItem);
            return RedirectToAction("AdminDashboard");
        }

        [HttpGet]
        public IActionResult DeleteEmp(int id)
        {
            _empRepositories.DeleteEmp(id);
            return RedirectToAction("EmployeeDashboard");
        }

        [HttpGet]
        public IActionResult EditEmployee(int id)
        {
            List<EmpModel> designations = _empRepositories.GetAllDesignation();
            ViewData["Designations"] = new SelectList(designations, "c_did", "c_dname");
            var emp = _empRepositories.ShowEmp(id);
            return View(emp);
        }

        [HttpPost]
        public IActionResult EditEmployee(int id, EmpModel updatedItem)
        {
            _empRepositories.UpdateEmp(id, updatedItem);
            return RedirectToAction("EmployeeDashboard");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}